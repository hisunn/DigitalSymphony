<!DOCTYPE html>
<html lang="en">
@include('head')

<body class="d-flex flex-column min-vh-100">
    @include('navbar')

    @include('detailsCard')

    {{-- <div style="margin-bottom: 15%"></div> --}}
    @include('footer')
</body>

</html>
