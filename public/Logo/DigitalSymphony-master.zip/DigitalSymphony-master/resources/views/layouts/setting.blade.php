<!DOCTYPE html>
<html lang="en">
@include('head')

<body class="d-flex flex-column min-vh-100">
    @include('navbar')
    @yield('content_three')

    @include('footer')
</body>

</html>
