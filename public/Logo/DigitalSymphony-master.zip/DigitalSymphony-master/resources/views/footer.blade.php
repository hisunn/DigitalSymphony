<footer class="py-5 border-top mt-auto bg-gray-100 shadow-sm">
    <div class="container">
        <p class="m-0 text-center text-gray-700">Copyright &copy; Ihsan Dzahri 2023</p>
    </div>
</footer>
<!-- Bootstrap core JavaScript-->

<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
{{-- <script src="js/scripts.js"></script> --}}
<script src="template/vendor/jquery/jquery.min.js"></script>
<script src="template/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="template/vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Custom scripts for all pages-->
<script src="template/js/sb-admin-2.min.js"></script>
<script src="template/js/ajax.js"></script>

